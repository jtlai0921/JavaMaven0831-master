package day06_enum;

public enum Sex {
    男生, 女生
}
