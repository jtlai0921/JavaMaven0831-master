package day07_innerclass;

public interface IPuppy {
    void skill();
}
