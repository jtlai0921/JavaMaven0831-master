package day08_enum;

public enum Level {
    員工, 經理, 副總, 總經理, 董事長
}
