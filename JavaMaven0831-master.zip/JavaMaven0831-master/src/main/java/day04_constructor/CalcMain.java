package day04_constructor;

public class CalcMain {
    public static void main(String[] args) {
        Calc calc = new Calc();
    }
}
