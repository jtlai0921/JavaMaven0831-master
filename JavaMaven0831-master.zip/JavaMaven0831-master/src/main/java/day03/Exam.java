package day03;

public class Exam {
    String subject; // 科目
    int score; // 分數

    @Override
    public String toString() {
        return "Exam{" + "subject=" + subject + ", score=" + score + '}';
    }
}
