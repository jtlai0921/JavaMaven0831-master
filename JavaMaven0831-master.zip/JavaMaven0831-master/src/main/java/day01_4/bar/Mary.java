package day01_4.bar;

public class Mary {
    public int money = 2000;
   
}
