package day01_4.foo;

public class Tom {
    protected int money = 5000;
    
}
