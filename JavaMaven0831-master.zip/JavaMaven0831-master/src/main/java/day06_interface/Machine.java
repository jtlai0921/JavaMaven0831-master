package day06_interface;

public interface Machine {
    int getVolt();
}
