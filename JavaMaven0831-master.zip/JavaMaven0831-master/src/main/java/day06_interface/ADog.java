package day06_interface;

public abstract class ADog implements IDog {

    @Override
    public void eat() {
        System.out.println("狗罐頭-寶路");
    }
    
}
