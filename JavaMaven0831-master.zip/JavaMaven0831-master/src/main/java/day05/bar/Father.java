package day05.bar;

public class Father {
    public int a = 100;
    protected int b = 200;
    int c = 300;
    private int d = 400;
}
