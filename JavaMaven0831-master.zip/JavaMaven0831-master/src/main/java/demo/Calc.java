package demo;

public class Calc {
    public int add(int x, int y) {
        return x + y;
    }
}
